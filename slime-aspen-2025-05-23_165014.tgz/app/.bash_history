ls
cd local
ls
cd src
ls
cd games
cd ../
ls
cd games
ls
cd ../
cd ../
cd /
ls
cd home
ls
cd app
cd ./.data/
ls
sqlite3
sqlite3
sqlite3
sqlite3
sqlite3
sqlite3
sqlite3 comment_section.db
ls
cd ../
ls
cd app
ls
sqlite3
sqlite3
nolllnollnol
ls
ls
pwd
ls
echo
echo hello
ls
ls
lss
ls
zzzzzls
ls
echo hello
lsecho hellhelllsechols
ls
ls
enable-npm.
enable-npm.
ls
ls
cd ../
ls
cd home
ls
cd ../
cd app
ls
sqlite3
ls
sqlite3
sqlite3
ls
sqlite3
ls
cd ../
ls
sqlite3
ls
cd app
ls
cat GreatIdeasandAuthors.db
cat sqlite.db
cat ideas.csv
cd views
ls
cd ../
cd public
ls
cd ../
ls
cd ../
ls
cd root
cd usr
ls
cd bin
ls
cd ../../
ls
cat db.sqlite3
ls
cat sqlite.db
cd cat db.sqlite
cd ../
ls
ls
sqlite3
ls
cd ../
cat sqlite.db
ls
ls
sqlite3
ls
ls
.databases
sqlite3
cd .data
ls
open sqlite.db
.tables
sqlite3
ls
cat notes.txt
ls
cd .data
ls
sqlite3
cd .data
open sqlite.db
ls
open sqlite.db
.databases
sqlite3
refresh
ls
cd .data
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
cd .data
ls
sqlite3
cd .data
ls
sqlite3
ls
cd ../
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
cd ../
ls
cd .data
sqlite3
cd .data
sqlite3
cd ../
ls
cd .data
sqlite3
ls
cd .data
ls
sqlite3
cd ../
refresh
ls
cd .data
ls
sqlite3
cd ../
ls
cd .data
sqlite3
cd ../
ls
cd .data
ls
sqlite3
cd ../
ls
ls
cd .data
ls
sqlite3
cd ../
ls
cd .data
sqlite3
cd ../
ls
cat ideas.csv
ls
ls
cd main
ls
sqlite3
list
ls
cat sqlite.db
cd main
ls
cd ../
cd .data
cd main
ls
cd app
ls
cd .data
sqlite3
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
sqlite3
ls
cat CLInotes.txt
ls
cd main
sqlite3
ls
cd data
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
ls
.databases
sqlite3
ls
cat notes
ls
sqlite3
cd ../
ls
ls
cd .data
sqlite3
ls
cat notes
ls
npm install ejs
npm audit fix
ls
cd .data
ls
open sqlite.db
sqlite
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
sqlite3
ls
ls
cd .data
ls
open sqlite.db
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
sqlite3
ls
ls
npm install -g npm@10.4.0
ls
cd .data
ls
sqlite3
cd ../
ls
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
cd ../
ls
ls
cd .data
sqlite3
ls
cd .data
ls
sqlite
sqlite3
ls
cd .data
sqlite3
ls
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
sqlite3
cd .data
sqlite3
ls
cd .data
sqlite3
cd .data
sqlite3
ls
ls
cd .data
sqlite3
ls
cd ../
ls
ls
cd .data
sqlite3
ls
cd .data
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
sqlite3
cd .data
sqlite3
cd .data
sqlite3
ls
cd .data
sqlite3
cd ../
ls
sqlite3
ls
cd .data
sqlite3
cd ../
ls
cd .data
sqlite3
cd .data
sqlite3
ls
cd .data
sqlite3
ls
cd .data
sqlite3
cd .data
sqlite3
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
cd ../
ls
ls
cd .data
sqlite3
ls
cd .data
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
sqlite3
cd ../
ls
cd .data
sqlite3
cd ../
ls
ls
cd .data
ls
cat notes.txt
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
ls
cat buggybracket
ls
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
ls
sqlite3
ls
cd .data
sqlite3
ls
ls
cd .data
ls
sqlite3
ls
cd ../
ls
ls
cd .data
ls
sqlite3
ls
cd ../
ls
ls
cd .data
ls
sqlite3
ls
cd ../
ls
cd .data
sqlite3
cd .data
ls
sqlite3
ls
ls
cd .data
ls
sqlite3
ls
cd ../
ls
ls
cd .data
ls
cat notes.txt
sqlite3
cd ../
ls
ls
cd .data
ls
cat notes
ls
sqlite3
ls
cd .data
sqlite3
ls
cd ../
ls
